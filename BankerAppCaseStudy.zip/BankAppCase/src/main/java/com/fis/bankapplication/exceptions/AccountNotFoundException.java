package com.fis.bankapplication.exceptions;

public class AccountNotFoundException extends Exception {
	public AccountNotFoundException(String message) {
		super(message);
	}
}
